Installation:
-Copy the .asi and .ini files into your GTA V folder 
-(optional, but much better)use openIV to place the file in the update folder structure in the same position in the update/update.rpf package
(in the timecycle folder). If you do not wish to use that feature, set 'snow' to 0 in the ini file. 

Note: plz no steal
